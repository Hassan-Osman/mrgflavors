<!-- Sidebar -->
      <ul class="sidebar navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="<?= base_url('mrgAdmin') ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link" href="<?= base_url('mrgAdmin') ?>">
            <span>Products</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?= base_url('mrgAdmin/orders') ?>">
            <span>Orders</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?= base_url('Auth/logout') ?>">
            <span>Logout</span></a>
        </li>
      </ul>

      <div id="content-wrapper">

        <div class="container-fluid">