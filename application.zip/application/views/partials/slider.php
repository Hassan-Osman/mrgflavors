<!-- revolution slider begin -->
<section id="section-slider">
  <div id="layerslider" class="wow fadeInDown">
        <!--layer slider starts-->
        <button onclick="window.location.href='<?= base_url('/product') ?>'" style="position: absolute;z-index: 3;left: 45%;top: 75%;background: #135ea3;color: #fff;border-radius: 5px;border: 0px;outline: 0px;padding: 5px 15px;width: 150px;font-size: 17px;">
        	Shop Now
        </button>
        <div class="ls-layer" style="slidedirection: top; slidedelay: 6000; durationin: 1500; durationout: 1500; delayout: 500;">
            <img src="<?= base_url('resources/images-slider/SH.jpg" class="ls-bg') ?>" alt="mrg" /> 
        </div>
    </div>
</section>
<!-- revolution slider close --> 
