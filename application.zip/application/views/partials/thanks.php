<section id="section-slider">
 <div class="spacer-double"></div>
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-md-offset-3 text-center wow fadeInUp">
            <h1>Thanks</h1>
            <div class="separator"><span><i class="fa fa-circle"></i></span></div>
            <div class="spacer-single"></div>
          </div>
           <div class="col-md-12">


                    <div class="box" id="contact">

                        

                        <p class="lead">Thank you for working with us, we will contact you in 24 Hours</p>


                    </div>


                </div>
                <!-- /.col-md-9 -->
          
        </div>
      </div>
      <div class="spacer-double"></div>
    </section>
    <!-- section close --> 

