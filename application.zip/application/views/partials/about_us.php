 <section id="section-slider">
 <div class="spacer-double"></div>
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-md-offset-3 text-center wow fadeInUp">
            <h1>About Us</h1>
            <div class="separator"><span><i class="fa fa-circle"></i></span></div>
            <div class="spacer-single"></div>
          </div>
           <div class="col-md-12">


                    <div class="box" id="contact">

                        

                        <p class="lead">We are Multi National Exporting, Importing and Manufacturing company. We started our career since 2006. <br />Our main Focus now is Flavors and the materials for DIY. We have all the materials you need to make your own enhanced Flavor.<br />
We are officially the First Affiliate in Egypt for Perfumer’s Apprentice ( TFA )<br /> <a href="http://shop.perfumersapprentice.com/affiliates.aspx">http://shop.perfumersapprentice.com/affiliates.aspx</a><br />
We Started Manufacturing in 2018 by Creating our Company in USA.<br />
Pyramids Industries L.L.C main activity is Manufacturing and designing the Best Premium Flavors and Distribute in Egypt and World Wide.<br />

We always seek to provide you with the best products and best quality in the market.
Our goal is to always exceed your satisfaction.</p>
<p>
Mostafa Mousa
CEO
</p>
<p>
Mr.G</p>


                    </div>


                </div>
                <!-- /.col-md-9 -->
          
        </div>
      </div>
      <div class="spacer-double"></div>
    </section>
    <!-- section close --> 

